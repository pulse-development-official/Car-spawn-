Registercommand ('spawncar', function(source, args, rawCommand)
    local vehicle = args [1]
    local x,y,z = table.unpack(GetOffsetFromEntityGivenWorldCoords(PlayerPedId(), 0.0, 2.5, 0.5))
    vehichlehash = GetHashKey(vehicle)
    RequestModel(vehichlehash)

    Citizen.CreateThread(threadFunction()
        while not HasModelLoaded(vehichlehash) do
            Citizen.Wait(0)
        end

        local spawned_Vehicle = CreateVehicle(vehichlehash, x, y, z, GetEntityHeading(PlayerPEdID()+9-,1,0)
        setVehiclleNumberPlateText(spawned_Vehicle, "Pulse")
        Notify (['~g~Fahrzeug ~w~erfolgreich ~g~gespawnt~w~!'])
    
    end)

end)

funktion Notify (msg)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg)
    DrawNotification(false, false)
end